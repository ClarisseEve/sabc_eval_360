

<?php $__env->startSection('header'); ?>

<div class="col-12">
    <p
        class="fs-1 mb-3 text-center"
        style="font-family: 'Montserrat', sans-serif"
    >
        <b>ACTIVITÉS <?php echo e(Auth::user()->type); ?> <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?></b> 
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row mb-3">
        <div class="col-md-6">
            <div class="card border-0 stats-card">
                <div class="card-body">
                    <p class="mb-0"> <span class="text-sabc-gray">Service commercial :</span> 
                        <?php echo e(json_decode(Auth::user()->service)[0]->sce_ccial); ?>    
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card border-0 stats-card">
                <div class="card-body">
                    <p class="mb-0"> <span class="text-sabc-gray">Region :</span> <?php echo e(session('user_region')); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- MD List -->
    <div class="card">
        <div
            class="card-header d-flex justify-content-between align-items-center"
        >
            <h5 class="mb-0"></h5>
            <a href="<?php echo e(route('csc.note.create' ,Auth::user()->matricule)); ?>"
                class="btn btn-sm btn-success"
            >
                <i class="bi bi-eye d-md-none"></i>
                <span class="d-none d-md-inline"
                    >S'Evaluer</span
                >
            </a>
            <!-- <button
                class="btn btn-danger btn-sm"
                onclick="window.location.href='new-pdv.html'"
            >
                + Nouveau PDV
            </button> -->
        </div>
        <div class="card-body">
            
            <table id="mdTable" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Type</th>
                        <th class="d-none d-sm-table-cell">
                            Nb Evaluation
                        </th>
                        <th>Note CSC</th>
                        <th>Note Personnelle</th>
                        <th>Dernière Evaluation</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($csc->name); ?></td>
                        <td><?php echo e($csc->type); ?></td>
                        <td><?php echo e($csc->evaluation_count ?? 'N/A'); ?></td>
                        <td><?php echo e($csc->latest_evaluation->total ?? 'N/A'); ?></td>
                        <td><?php echo e('N/A'); ?></td>
                        <td><?php echo e($csc->created_at ?? 'N/A'); ?></td>
                        <td>
                            <div class="btn-group">
                                <a href="<?php echo e(route('csc.note.create' ,$csc->matricule)); ?>"
                                    class="btn btn-sm btn-info"
                                >
                                    <i class="bi bi-eye d-md-none"></i>
                                    <span class="d-none d-md-inline"
                                        >Evaluer</span
                                    >
                                </a>
                                <a href="<?php echo e(route('csc.show' ,$csc->matricule)); ?>"
                                    class="btn btn-sm btn-success"
                                >
                                    <i class="bi bi-eye d-md-none"></i>
                                    <span class="d-none d-md-inline"
                                        >Détails</span
                                    >
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $colleagues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colleague): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $routePrefix = strtolower($colleague->type);
                        ?>
                        <tr>
                            <td><?php echo e($colleague->name); ?></td>
                            <td><?php echo e($colleague->type); ?></td>
                            <td><?php echo e($colleague->evaluation_count ?? 'N/A'); ?></td>
                            <td><?php echo e($colleague->latest_evaluation->total ?? 'N/A'); ?></td>
                            <td><?php echo e($colleague->latest_evaluation->total ?? 'N/A'); ?></td>
                            <td><?php echo e($colleague->created_at ?? 'N/A'); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route("csc.{$routePrefix}.create", $colleague->matricule)); ?>"
                                        class="btn btn-sm btn-info"
                                    >
                                        <i class="bi bi-eye d-md-none"></i>
                                        <span class="d-none d-md-inline">Evaluer</span>
                                    </a>
                                    <a href="<?php echo e(route("csc.{$routePrefix}.index", $colleague->matricule)); ?>"
                                        class="btn btn-sm btn-success"
                                    >
                                        <i class="bi bi-eye d-md-none"></i>
                                        <span class="d-none d-md-inline">Détails</span>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digex\p-nam\resources\views/csc/dashboard.blade.php ENDPATH**/ ?>