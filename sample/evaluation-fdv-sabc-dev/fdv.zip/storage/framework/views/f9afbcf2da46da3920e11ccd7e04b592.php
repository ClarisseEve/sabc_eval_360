

<?php $__env->startSection('content'); ?>
<div class="container mt-5 mb-3">
    <div class="card shadow-lg">

        <div class="card-header d-flex justify-content-between">
            
            <h2 class="text-center mb-4">
                <a href=<?php echo e(route('csc.dashboard' )); ?> class="text-decoration-none text-sabc-gray">
                    <i class="bi bi-arrow-left"></i> 
                </a>
                Formulaire d'Évaluation <?php echo e(Auth::user()->type); ?> : <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?>

            </h2>
        </div>
        <div class="card-body">
            <form id="evaluationForm" method="POST" action="<?php echo e(route('csc.note.store' ,Auth::user()->matricule)); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <p class="text-muted">Veuillez évaluer chaque compétence en sélectionnant un niveau.</p>
                    </div>
                </div>
                <div class="row"> 
                    <input class="form-control" type="hidden" name="nom_utilisateur" id="nom_utilisateur" value="<?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?>">
                    <input class="form-control" type="hidden" name="id_utilisateur" id="id_utilisateur" value="<?php echo e(Auth::user()->matricule); ?>">
                    <!-- Dynamic Skill Sections -->
                    <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skillName => $descriptions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-3" data-weight="<?php echo e($descriptions[0]); ?>">
                        <div class="card p-3">
                            <label class="form-label fw-bold"><?= htmlspecialchars($skillName) ?></label>
                            <div class="d-flex justify-content-between flex-wrap">
                                <?php foreach ($descriptions[1] as $index => $description): ?>
                                    <div class="form-check" data-bs-toggle="tooltip" data-bs-placement="top" title="<?= htmlspecialchars($description) ?>">
                                        <input class="form-check-input" type="radio" name="<?= htmlspecialchars(str_replace(' ', '_', $skillName)) ?>" value="<?= $index + 1 ?>">
                                        <label class="form-check-label">Niveau <?= $index + 1 ?></label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex justify-content-between gap-2">
                    <button type="reset" class="btn btn-outline-sabc-red">
                        <i class="bi bi-x-circle"></i> Réinitialiser
                    </button>
                    <button type="submit" class="btn btn-sabc-red">
                        <i class="bi bi-check-circle"></i> Evaluer
                    </button>
                </div>
                
            </form>
        </div>
        <div class="card-footer">
            
        </div>
        
    </div>

</div>

<!-- Results Modal -->
<div class="modal fade" id="scoreModal" tabindex="-1" aria-labelledby="scoreModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="scoreModalLabel">Résultat d'évaluation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <div class="position-relative d-inline-block">
                    <div id="circularProgress" class="position-relative" style="width: 200px; height: 200px;">
                        <svg width="200" height="200" viewBox="0 0 200 200">
                            <circle cx="100" cy="100" r="90" fill="none" stroke="#e9ecef" stroke-width="15"/>
                            <circle id="progressCircle" cx="100" cy="100" r="90" fill="none" stroke="#E83643" 
                                stroke-width="15" stroke-dasharray="565.48" stroke-dashoffset="565.48" 
                                transform="rotate(-90 100 100)"/>
                        </svg>
                        <div class="position-absolute top-50 start-50 translate-middle text-center">
                            <div id="scoreValue" class="fs-1 fw-bold text-sabc-red">0</div>
                            <div class="small">sur <span id="maxScore">100</span></div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <h6>Évaluation globale de <span id="evaluatedUser">[Nom]</span>: <span id="percentageValue">0%</span></h6>
                </div>
                
                <div class="mt-3" id="completionStatus"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                <button type="button" class="btn btn-sabc-red" id="saveEvaluation" onclick="submitEvaluation()">Enregistrer l'évaluation</button>        
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
// Configuration
const config = {
    maxScore: 100,
    animationDuration: 800,
    formTypes: {
        csc: { sections: 21, endpoint: './action/note_cds.php' },
        cdv: { sections: 24, endpoint: './action/note_cdv.php' }
    }
};

// DOM Elements
const elements = {
    form: document.getElementById('evaluationForm'),
    scoreModal: document.getElementById('scoreModal'),
    progressCircle: document.getElementById('progressCircle'),
    scoreValue: document.getElementById('scoreValue'),
    percentageValue: document.getElementById('percentageValue'),
    completionStatus: document.getElementById('completionStatus'),
    evaluatedUser: document.getElementById('evaluatedUser'),
    saveButton: document.getElementById('saveEvaluation'),
    userInput: document.getElementById('nom_utilisateur')
};

// Initialize tooltips
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Calculate and display score
function calculateAndShowScore() {
    const sections = document.querySelectorAll('.col-md-6.mb-3[data-weight]');
    const userName = elements.userInput.value || '<?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?>';
    
    let totalScore = 0;
    let maxPossibleScore = 0;
    let completedSections = 0;
    
    sections.forEach(section => {
        // Get the weight of the section (as a percentage)
        const weight = parseFloat(section.getAttribute('data-weight'));
        const selectedRadio = section.querySelector('input[type="radio"]:checked');
        
        if (selectedRadio) {
            // Calculate the weighted score for this section
            const level = parseFloat(selectedRadio.value); // 1-5
            const maxLevel = 5; // Maximum level for each section
            
            // Calculate section score (level/maxLevel * weight)
            const sectionScore = (level / maxLevel) * weight;
            totalScore += sectionScore;
            
            // Calculate max possible score for this section (weight)
            maxPossibleScore += weight;
            
            // Increment completed sections
            completedSections++;
        }
    });
    
    // Calculate overall percentage (round to 2 decimal places)
    const overallPercentage = maxPossibleScore > 0 ? Math.round((totalScore / maxPossibleScore) * 100 * 100) / 100 : 0;
    
    // Update UI
    elements.scoreValue.textContent = overallPercentage;
    elements.percentageValue.textContent = `${overallPercentage}%`;
    elements.evaluatedUser.textContent = userName;
    
    // Update progress circle animation
    const circumference = 2 * Math.PI * 90;
    const offset = circumference - (overallPercentage / 100) * circumference;
    elements.progressCircle.style.strokeDashoffset = offset;
    
    // Update completion status
    if (completedSections < sections.length) {
        elements.completionStatus.innerHTML = `
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle"></i> 
                ${completedSections} sur ${sections.length} catégories évaluées. Veuillez compléter toutes les catégories.
            </div>`;
        elements.saveButton.style.display = 'none';
    } else {
        elements.completionStatus.innerHTML = `
            <div class="alert alert-success">
                <i class="bi bi-check-circle"></i> Évaluation complète!
            </div>`;
        elements.saveButton.style.display = 'block';
    }
    
    // Show modal
    const modal = new bootstrap.Modal(elements.scoreModal);
    modal.show();
}

// Submit evaluation
function submitEvaluation() {
    alert('okay lets save');
    elements.form.submit(); // Submits the form normally (page reloads)
}

// Toggle form view
function toggleFormView() {
    const checkbox = document.getElementById('auto_evaluer');
    const userSection = document.getElementById('utilisateur');
    
    if (checkbox) {
        userSection.style.display = checkbox.checked ? 'block' : 'none';
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    initTooltips();
    
   elements.form.addEventListener('submit', function(e) {
        e.preventDefault();
        calculateAndShowScore();
    });
    
    // Reset form
    document.querySelector('button[type="reset"]').addEventListener('click', function() {
        document.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.checked = false;
        });
    });
});
</script>

<style>
#progressCircle {
    transition: stroke-dashoffset 0.8s ease-in-out;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .form-check {
        margin-bottom: 0.5rem;
    }
    
    .col-md-6.mb-3 .card {
        padding: 1rem;
    }
    
    .d-flex.justify-content-between {
        flex-direction: column;
        gap: 0.5rem;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digex\p-nam\resources\views/csc/note.blade.php ENDPATH**/ ?>