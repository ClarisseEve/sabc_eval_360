


<?php $__env->startSection('header'); ?>

<div class="col-12">
    <p
        class="fs-1 mb-3 text-center"
        style="font-family: 'Montserrat', sans-serif"
    >
        <b>ACTIVITÉS <?php echo e(Auth::user()->type); ?> <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?></b> 
    </p>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="card">
        <div
            class="card-header d-flex justify-content-between align-items-center"
        >
            <h5 class="mb-0">Personnelles</h5>

            <a
                class="btn btn-danger btn-sm"
                href="<?php echo e(route('admin.users.create')); ?>"
            >
                Nouveau Personnel
            </a>
        </div>
        <div class="card-body">
            <table id="pdvTable" class="table table-striped">
                <thead>
                    <tr>
                        <th>Matricule</th>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->matricule); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->surname); ?></td>
                            <td><?php echo e($user->type); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.users.show', $user->matricule)); ?>" class="btn btn-sm btn-sabc-red">
                                    Détails
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digex\p-nam\resources\views/admin/index.blade.php ENDPATH**/ ?>