


<?php $__env->startSection('header'); ?>

<div class="col-12">
    <p
        class="fs-2 mb-3 text-center"
        style="font-family: 'Montserrat', sans-serif"
    >
        <b>ACTIVITÉS <?php echo e(Auth::user()->type); ?> <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?></b> 
    </p>
</div>

<div class="col-12">
    <p
        class="fs-1 mb-3 text-center text-uppercase"
        style="font-family: 'Montserrat', sans-serif"
    >
        <b>ACTIVITÉS <?php echo e($evaluation->user->type); ?> <?php echo e($evaluation->user->surname); ?> <?php echo e($evaluation->user->name); ?></b> 
    </p>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-2  mb-3">
                <div class="card border-0 stats-card">
                    <div class="card-body text-center">
                        <a href="<?php echo e(url()->previous()); ?>" class="text-decoration-none text-sabc-gray">
                            <i class="bi bi-arrow-left"></i> Retour
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card border-0 stats-card">
                    <div class="card-body">
                        <p class="mb-0"> <span class="text-sabc-gray">Service commercial :</span> <?php echo e(json_decode($evaluation->user->service)[0]->sce_ccial); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card border-0 stats-card">
                    <div class="card-body">
                        <p class="mb-0"> <span class="text-sabc-gray">Region :</span> <?php echo e($region); ?> </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-header bg-sabc-red text-white">
                <h5 class="mb-0">Note</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <p><strong>Name:</strong> <?php echo e($evaluation->user->name); ?> <?php echo e($evaluation->user->surname); ?></p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Matricule:</strong> <?php echo e($evaluation->user->matricule); ?></p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Type:</strong> <?php echo e($evaluation->user->type); ?></p>
                    </div>
                    
                    <div class="col-md-4">
                        <p><strong>Total:</strong> <?php echo e($evaluation->total ?? 'N/A'); ?></p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Service:</strong> <?php echo e($evaluation->user->service->first()->sce_ccial ?? 'N/A'); ?></p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Region:</strong> <?php echo e($region); ?></p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Evaluation Date:</strong> <?php echo e($evaluation->created_at->format('d/m/Y')); ?></p>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card">
            <div
                class="card-header d-flex justify-content-between align-items-center"
            >
                <h5 class="mb-0">Détail Note</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="mdTable" class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th width="30%">Criteria</th>
                                <th width="10%">Score</th>
                                <th width="50%">Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = json_decode($evaluation->notes, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($criterion); ?></td>
                                <td><?php echo e($data); ?>/5</td>
                                <td class="small">
                                    <?php echo e($labels[$criterion][1][$data - 1] ?? 'No description available'); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digex\p-nam\resources\views/admin/users/note.blade.php ENDPATH**/ ?>