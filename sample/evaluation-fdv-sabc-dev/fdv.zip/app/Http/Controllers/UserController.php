<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Services_cciaux;
use App\Models\Regions;
use App\Models\UserService;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    
}
