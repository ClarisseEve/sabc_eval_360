<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class AuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'name' => 'required|string',
            'password' => 'required|string',
        ]);
        // Attempt to authenticate using the 'users' table
        if (Auth::attempt(['login' => $request->name, 'password' => $request->password])) {
             $user = Auth::user();
            $request->session()->regenerate();
            //  dd($user->type);
            return redirect()->intended($this->getUserDashboardRoute($user->type));
        }
        return back()->withErrors([
            'login' => 'The provided credentials do not match our records.',
        ])->onlyInput('name');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }

    private function getUserDashboardRoute($userType)
    {
        $routes = [
            'CDS' => 'cds.dashboard',
            'CDV' => 'cdv.dashboard',
            'CSC' => 'csc.dashboard',
            'ADMIN' => 'admin.dashboard',
        ];

        return route($routes[$userType] ?? 'login');
    }
}
