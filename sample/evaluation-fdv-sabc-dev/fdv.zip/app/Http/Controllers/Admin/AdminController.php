<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{User, Notes, Regions};


class AdminController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('admin.index',compact('users'));
    }
}
