@extends('layout.form')

@section('content')
    <div class="container mt-5">
        <div class="card shadow-lg p-4">
            <div class="card-header">
                <h2 class="text-center mb-4">
                    <a href="{{ url()->previous() }}" class="text-decoration-none text-sabc-gray">
                        <i class="bi bi-arrow-left"></i> 
                    </a>
                    Formulaire d'Évaluation {{ Auth::user()->type }} {{ Auth::user()->surname }} {{  Auth::user()->name }}
                </h2>
            </div>
            <div class="card-body">
                <form id="evaluationForm" method="POST" action="{{ route('cds.note.store') }}">
                    @csrf
                    <div class="row">
                        <div class="col-md-12">
                            <p class="text-muted">Veuillez évaluer chaque compétence en sélectionnant un niveau.</p>
                        </div>
                    </div>
                    <div class="row"> 
                        <input class="form-control" type="hidden" name="nom_utilisateur" id="nom_utilisateur" value="{{ Auth::user()->surname }} {{  Auth::user()->name }}">
                        <input class="form-control" type="hidden" name="id_utilisateur" id="id_utilisateur" value="{{ Auth::user()->matricule }}">
                        <!-- Dynamic Skill Sections -->
                        @foreach($labels as $skillName => $descriptions)
                        <div class="col-md-6 mb-3" data-weight="{{ $descriptions[0] }}">
                            <div class="card p-3">
                                <label class="form-label fw-bold"><?= htmlspecialchars($skillName) ?></label>
                                <div class="d-flex justify-content-between flex-wrap">
                                    <?php foreach ($descriptions[1] as $index => $description): ?>
                                        <div class="form-check" data-bs-toggle="tooltip" data-bs-placement="top" title="<?= htmlspecialchars($description) ?>">
                                            <input class="form-check-input" type="radio" name="<?= htmlspecialchars(str_replace(' ', '_', $skillName)) ?>" value="<?= $index + 1 ?>">
                                            <label class="form-check-label">Niveau <?= $index + 1 ?></label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        @endforeach
                    </div> 
                </form>
            </div>
            <div class="card-footer">
                <div class="d-flex justify-content-between gap-2">
                    <button type="reset" class="btn btn-sabc-red">
                        <i class="bi bi-x-circle"></i> Réinitialiser
                    </button>
                    <button class="btn btn-sabc-red" id="showModal">
                        <i class="bi bi-check-circle"></i> Evaluer
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script>
// DOM Elements
        const elements = {
            form: document.getElementById('evaluationForm'),
            scoreModal: document.getElementById('scoreModal'),
            progressCircle: document.getElementById('progressCircle'),
            scoreValue: document.getElementById('scoreValue'),
            percentageValue: document.getElementById('percentageValue'),
            completionStatus: document.getElementById('completionStatus'),
            evaluatedUser: document.getElementById('evaluatedUser'),
            saveButton: document.getElementById('saveEvaluation'),
            userInput: document.getElementById('nom_utilisateur'),
            showModal: document.getElementById('showModal')
        };



        // Function to sum checked radio values and display in modal with circular progress
        function calculateAndShowScore() {
            // Get all sections with a data-weight attribute
            const sections = document.querySelectorAll('.col-md-6.mb-3[data-weight]');
            const nom_utilisateur = document.getElementById('nom_utilisateur').value;
            let totalWeight = 0;
            let total = 0;
            let totalScore = 0;
            let overall = 68;
            let completedSections = 0;

            // Process each section
            sections.forEach(section => {
                // Get the weight of the section
                const weight = parseFloat(section.getAttribute('data-weight'));
                // Get the selected radio button in this section
                const selectedRadio = section.querySelector('input[type="radio"]:checked');
                if (selectedRadio) {
                    // Calculate the weighted score for this section
                    const level = parseFloat(selectedRadio.value);
                    const maxLevel = 5; // Maximum level for each section
                    const sectionScore = (level / maxLevel) * weight; // Weighted score
                    totalScore+= (sectionScore / overall) * 100;
                    console.log('note' + sectionScore);
                    // Increment completed sections
                    completedSections++;
                }
            });

            // Calculate overall percentage
            const maxPossibleScore = 100; // Total possible score is 100%
            const overallPercentage = Math.round(totalScore);

            console.log(totalScore);

            // Create modal if it doesn't exist
            if (!document.getElementById('scoreModal')) {
                const modalHTML = `
                    <div class="modal fade" id="scoreModal" tabindex="-1" aria-labelledby="scoreModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="scoreModalLabel">Résultat d'évaluation</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body text-center">
                                    <div class="position-relative d-inline-block">
                                        <!-- Circular progress container -->
                                        <div id="circularProgress" class="position-relative" style="width: 200px; height: 200px;">
                                            <!-- Background circle -->
                                            <svg width="200" height="200" viewBox="0 0 200 200">
                                                <circle cx="100" cy="100" r="90" fill="none" stroke="#e9ecef" stroke-width="15"/>
                                                <!-- Progress circle -->
                                                <circle id="progressCircle" cx="100" cy="100" r="90" fill="none" stroke="#E83643" 
                                                    stroke-width="15" stroke-dasharray="565.48" stroke-dashoffset="565.48" 
                                                    transform="rotate(-90 100 100)"/>
                                            </svg>
                                            <!-- Score display in the center -->
                                            <div class="position-absolute top-50 start-50 translate-middle text-center">
                                                <div id="scoreValue" class="fs-1 fw-bold text-sabc-red">0</div>
                                                <div class="small">sur <span id="maxScore">100</span></div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4">
                                        <h6>Évaluation globale de ${nom_utilisateur}: <span id="percentageValue">0%</span></h6>
                                    </div>
                                    
                                    <div class="mt-3" id="completionStatus"></div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                    <button type="button" class="btn btn-sabc-red" id="saveEvaluation" onclick="submitEvaluation()">Enregistrer l'évaluation</button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                // Add modal to DOM
                document.body.insertAdjacentHTML('beforeend', modalHTML);
                
                // Add style for smooth transition
                const style = document.createElement('style');
                style.textContent = `
                    #progressCircle {
                        transition: stroke-dashoffset 0.8s ease-in-out;
                    }
                `;
                document.head.appendChild(style);
            }
            
            // Update score display
            document.getElementById('scoreValue').textContent = overallPercentage;
            document.getElementById('maxScore').textContent = maxPossibleScore;
            document.getElementById('percentageValue').textContent = overallPercentage + '%';
            
            // Update circular progress
            const circumference = 2 * Math.PI * 90;
            const offset = circumference - (overallPercentage / 100) * circumference;
            const progressCircle = document.getElementById('progressCircle');
            progressCircle.style.strokeDasharray = circumference;
            progressCircle.style.strokeDashoffset = offset;
            
            // Update completion status
            const completionElement = document.getElementById('completionStatus');
            const save = document.getElementById('saveEvaluation');
            if (completedSections < sections.length) {
                completionElement.innerHTML = `<div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle"></i> 
                    ${completedSections} sur ${sections.length} catégories évaluées. Veuillez compléter toutes les catégories.
                </div>`;
                save.style.display = 'none';
            } else {
                completionElement.innerHTML = `<div class="alert alert-success">
                    <i class="bi bi-check-circle"></i> Évaluation complète!
                </div>`;
                save.style.display = 'block';
            }
            // Show the modal
            const scoreModal = new bootstrap.Modal(document.getElementById('scoreModal'));
            scoreModal.show();
        }

       // Submit evaluation
       function submitEvaluation() {
           elements.form.submit(); // Submits the form normally (page reloads)
           alert('okay lets save');
        }
        // Add event listeners after DOM is loaded
         // Initialize
         document.addEventListener('DOMContentLoaded', function() {
            elements.showModal.addEventListener('click', function(e) {
                e.preventDefault();
                calculateAndShowScore();
            });
            // Reset form
            document.querySelector('button[type="reset"]').addEventListener('click', function() {
                document.querySelectorAll('input[type="radio"]').forEach(radio => {
                    radio.checked = false;
                });
            });
        });
    </script>
@endsection