@extends('layout.admin')

@section('header')

<div class="col-12">
    <p
        class="fs-2 mb-3 text-center"
        style="font-family: 'Montserrat', sans-serif"
    >
        <b>ACTIVITÉS {{ Auth::user()->type }} {{ Auth::user()->surname }} {{  Auth::user()->name }}</b> 
    </p>
</div>
@endsection


@section('container')
    <div class="container">
        
        <div class="card">
            <div
                class="card-header d-flex justify-content-between align-items-center"
            >
                <h5 class="mb-0">Rapport Final</h5>
            </div>

            <div class="card-body table-responsive-lg">
                <table id="pdvTable" class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Region</th>
                            <th>Service</th>
                            <th>Type</th>
                            <th>Evaluateur</th>
                            <th>Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $user)
                            @if ($user['type'] !== 'DR' && $user['type'] !== 'CDC TT')
                                @foreach ($user['evaluation'] as $evaluation)                                   
                                    <tr>
                                        <td>{{ $user['name'] }}</td>
                                        <td>{{ $user['region'] }}</td>
                                        <td>{{ $user['service'] }}</td>
                                        <td>{{ $user['type'] }}</td>
                                        <td>{{ $evaluation['creator'] == $user['name'] ? 'Auto' : $evaluation['creator']}}</td>
                                        <td>{{ $evaluation['score'] }} / 20</td>
                                        
                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td>{{ $user['name'] }}</td>
                                    <td>{{ $user['region'] }}</td>
                                    <td>N/A</td>
                                    <td>{{ $user['type'] }}</td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                            @endif
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

@section('script')

@endsection